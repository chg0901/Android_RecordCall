package edu.kwangwoon.chenghong.callrecord;

/**
 * Created by CHG on 2017/11/10.
 */

public class DbContract {

    public static final String TABLE_NAME = "incomingInfo";
    public static final String INCOMING_NUMBER = "incomingNumber";

    public static final String UPDATE_UI_FILTER = "edu.kwangwoon.chenghong.callrecord.UPDATE_UI";



}
